#include "stdafx.h"
#include "DamageProcessor.h"
#include "DamageIndicatorPool.h"

namespace
{
	const auto DAMAGE_TEXT_OFFSET_Y = 120.0f;
}


namespace nsApp
{
	DamageIndicatorPool* DamageProcessor::m_damageIndicatorPool = nullptr;


	void DamageProcessor::SetDamageIndicatorPool(DamageIndicatorPool* damageIndicatorPool)
	{
		m_damageIndicatorPool = damageIndicatorPool;
	}


	bool DamageProcessor::ApplyDamage(const DamageRequest& request)
	{
		if (!IsValidRequest(request))
			return false;

		/* �_���[�W��t�^�B*/
		request.target->ApplyDamage(request.damageAmount);

		/* �_���[�W�t�H���g�̕\�����˗��B*/
		SpawnDamageIndicator(request.damageAmount, request.hitPosition);

		return true;
	}


	DamageRequest DamageProcessor::BuildTargetDamageRequest(nsActor::ICharacter* targetCharacter, int damageAmount)
	{
		DamageRequest request;
		request.target = targetCharacter;
		request.damageAmount = damageAmount;

		if (targetCharacter != nullptr)
		{
			request.hitPosition = targetCharacter->GetPosition();
			request.hitPosition.y += DAMAGE_TEXT_OFFSET_Y;
		}

		return request;
	}


	bool DamageProcessor::IsValidRequest(const DamageRequest& request)
	{
		/* �ڕW�����݂��Ȃ��ꍇ�A�������s��Ȃ��B*/
		if (request.target == nullptr)
			return false;

		/* �_���[�W����0�̏ꍇ�A�������s��Ȃ��B*/
		if (request.damageAmount <= 0)
			return false;

		return true;
	}


	void DamageProcessor::SpawnDamageIndicator(int damageValue, const Vector3& position)
	{
		if (m_damageIndicatorPool == nullptr)
			return;

		m_damageIndicatorPool->SpawnDamageText(damageValue, position);
	}
}