#pragma once
/**
* @file   SwordCharacter.h
* @brief  SwordPlayer���Ǘ����Ǌ�����N���X�B
* @author YamaguchiHayato�B
* @date   2026\04/02
*/

#include "Src/Actor/Character/Player/Player.h"
#include "IWeaponCharacter.h"

namespace nsApp
{
	namespace nsActor
	{
		class SwordCharacter : public IWeaponCharacter
		{
		public:
			SwordCharacter() = default;
			virtual ~SwordCharacter() = default;


		public:
			/**
			* �������B
			*/
			bool Start() override;


		protected:
			void RegisterState() override;
		};
	}
}


