#include "stdafx.h"
#include "NPCAttackBaseState.h"
#include "Src/Actor/Character/Player/InputSystem/VirtualInputAdapter.h"

namespace
{
	const auto CLIPPING_LIMIT_DISTANCE = 40.0f;     //! �N���b�s���O��h�~���鋗���B
}

namespace nsApp
{
	namespace nsState
	{
		void NPCAttackBaseState::Enter()
		{
			/* �L���X�g�B*/
			m_npcBrain = static_cast<NPCBrain*>(m_owner);

			/* NPC�̑̂��擾�B*/
			m_getBody = m_npcBrain->GetBody();

			/* NPCBrain�N���X����Adapter���擾�B*/
			m_virtualInput = m_npcBrain->GetVirtualInputAdapter();

			/* �^�C�}�[���������B*/
			SetAttackTimer(0);
		}


		void NPCAttackBaseState::Exit()
		{
			if (m_virtualInput)
				m_virtualInput->Reset();
		}


		void NPCAttackBaseState::PreventClipping(nsActor::ICharacter* target)
		{
			if (m_distance >= CLIPPING_LIMIT_DISTANCE || m_distance <= 0.0f)
				return;

			m_pushBakeDirection = m_getBody->GetPosition() - target->GetPosition();
			m_pushBakeDirection.y = 0.0f;
			m_pushBakeDirection.Normalize();

			m_currentPosition = m_getBody->GetPosition();
			m_currentPosition.x += m_pushBakeDirection.x * (CLIPPING_LIMIT_DISTANCE - m_distance);
			m_currentPosition.z += m_pushBakeDirection.z * (CLIPPING_LIMIT_DISTANCE - m_distance);

			m_getBody->GetCharacterController().SetPosition(m_currentPosition);
			m_getBody->SetPosition(m_currentPosition);
		}


		void NPCAttackBaseState::UpdateFacingDirection()
		{
			if (m_isAttacking) {
				m_getBody->SetAngle(m_diff.x > 0.0f ? 90.0f : -90.0f);
				m_getBody->SetForwardVector(m_diff.x > 0.0f ? Vector3::Right : Vector3::Left);
			}
		}


		void NPCAttackBaseState::ResetVirtualInputs() 
		{
			if (!m_virtualInput)
				return;
		}
	}
}